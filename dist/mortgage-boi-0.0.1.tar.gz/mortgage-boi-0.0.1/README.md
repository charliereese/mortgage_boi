# Description

mortgage-boi is a python package for calculating mortgage data and cash flows.
